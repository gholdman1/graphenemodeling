import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.animation as animation

from scipy import integrate, optimize

from abc import ABCMeta # For inheritance

__version__='1.0.2'

import matplotlib.pyplot as plt
import matplotlib.cm as cm


def SelectImage(images):
	'''
	Provides 
	'''
	pass

